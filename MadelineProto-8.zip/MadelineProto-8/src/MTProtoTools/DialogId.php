<?php declare(strict_types=1);

namespace danog\MadelineProto\MTProtoTools;

use danog\DialogId\DialogId;

class_alias(DialogId::class, 'danog\\MadelineProto\\MTProtoTools\\DialogId');
